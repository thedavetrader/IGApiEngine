
go

create procedure delete_watchlist
    @watchlist_id   nvarchar(4000)
as begin

  set nocount on

  declare @message                    nvarchar(max)
  declare @timeout                    int             = 60 * 100;
  declare @found                      bit = 1
  declare @api_engine_status_is_alive bit = 0
  declare @retry                      int = 0

  insert  api_request_queue_item (
          request
  ,       parameter
  ,       execute_asap    )
  select  request         = 'DeleteWatchlist'
  ,       parameter       = wl.watchlist_id
  ,       execute_asap    = 1
  from    watchlist       wl
  where   wl.watchlist_id = @watchlist_id

  if @@rowcount = 0
      throw 51000, 'The specified watchlistid or epic could not be found', 1

  while   (   @found = 1  or @api_engine_status_is_alive = 0)
  and     @retry < @timeout
  begin

    set     @api_engine_status_is_alive = dbo.get_api_engine_status_is_alive()

    set     @found    = coalesce( ( select  1
                                    from    watchlist w
                                    where   w.watchlist_id = @watchlist_id )
                                , 0 )

    waitfor delay '00:00:00:010'

    set @retry += 1

  end

  if @found = 0 and @api_engine_status_is_alive = 1
  begin

    set @message = 'Watchlist with id" ' + @watchlist_id + '" is  deleted.'      
    raiserror(@message , 10, 10) with nowait

  end
  else
  begin
        
    if  @api_engine_status_is_alive = 0
    begin 

      --      Api interface is not alive or is in abnormal state. 
      --      Prevent the request will be untimely executed when interface is recovered by removing it from queue.
      delete  rrq
      from    api_request_queue_item  rrq
      where   request                 = 'DeleteWatchlist'

      set @message = 'ApiEngine does not report active and alive.'
      raiserror(@message, 10, 10) with nowait

    end
        
    if  @found = 1
    begin
        
      set @message = 'Failed to delete Watchlist with id "' + @watchlist_id + '".'
      raiserror(@message, 10, 10) with nowait

    end

    return -2

  end

end

go

--exec    delete_watchlist 
--        @watchlist_id   = 16506649
