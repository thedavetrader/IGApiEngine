﻿create procedure api_engine_shutdown
	@immediately	bit = 0
as begin

	set nocount on

	insert	api_request_queue_item (
			request
	,		execute_asap 
	)
	select	'Shutdown'
	,		@immediately

end

go

--api_engine_shutdown	@immediately = 1