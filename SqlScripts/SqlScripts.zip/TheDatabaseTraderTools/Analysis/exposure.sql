use tdt_live

go



create function get_exposure_insight_v2 (
      @timestamp        datetime2      
,     @time_in_market   int            
,     @capital          decimal(38,19) 
,     @risk_percentage  decimal(38,19) )
returns table
as return (

  select  broker_ticker_reference                         = x.broker_ticker_reference
  ,       name                                            = x.name
  ,       is_expo_size_valid                                        = iif(es.exposure_size >= x.min_required_exposure_size, 1, 0)
  ,       min_required_exposure_size                      = x.min_required_exposure_size
  ,       exposure_size                                   = es.exposure_size
  ,       exposure_spread_notional_value_in_eur           = ex.exposure_spread_notional_value_in_eur
  ,       exposure_price_volatility_notional_value_in_eur = ex.exposure_price_volatility_notional_value_in_eur
  ,       volatility_to_spread_ratio                      = x.volatility_to_spread_ratio
  ,       relative_volatility_to_spread_ratio             = x.volatility_to_spread_ratio / x.relative_volatility_perc
  ,       relative_volatility_perc                        = x.relative_volatility_perc
  ,       client_long_perc                                = x.client_long_perc
  ,       client_short_perc                               = x.client_short_perc             
  ,       client_sentiment_strength                       = (select max(m.perc) from (select perc=x.client_long_perc union select perc=x.client_short_perc) m)
  from    ( select  broker_ticker_reference               = ed.broker_ticker_reference
            ,       name                                        = ed.name
            ,       spread_notional_value_in_eur                = n.spread_notional_value_in_eur           
            ,       min_required_exposure_size                  = n.min_required_exposure_size              
            ,       price_volatility_notional_value_in_eur      = n.price_volatility_notional_value_in_eur                   
            ,       volatility_to_spread_ratio                  = n.price_volatility_notional_value_in_eur / spread_notional_value_in_eur
            ,       relative_volatility_perc                    = relative_volatility_perc
            ,       client_long_perc                            = cc.long_position_percentage
            ,       client_short_perc                           = cc.short_position_percentage
            /*      Parked  */
            --,       offer                                       = cc.offer
            --,       bid                                         = cc.bid
            --,       price                                       = p.price
            --,       spread                                      = (cc.offer - cc.bid)
            --,       price_volatility                            = v.price_volatility  
            --,       offer_notional_value_in_eur                 = n.offer_notional_value_in_eur            
            --,       bid_notional_value_in_eur                   = n.bid_notional_value_in_eur            
            --,       price_notional_value_in_eur                 = n.price_notional_value_in_eur            

            from    chart_candle                        cc

            cross
            apply   ( select  price_volatility          = 2*stdev(pv.price)
                      ,       relative_volatility_perc  = 2*stdev(pv.price) * 100.0 / avg(pv.price)
                      from    chart_candle            ccv
                      cross
                      apply   ( select  price         = (ccv.offer + ccv.bid) / 2.0 ) pv
                      where   ccv.broker_ticker_reference = cc.broker_ticker_reference
                      and     ccv.timestamp               between dateadd(minute, -@time_in_market, @timestamp)
                                                          and     @timestamp  ) v

            join    ticker_detail                       ed
            on      ed.broker_ticker_reference          = cc.broker_ticker_reference

            left
            join    ticker_detail_override              tdo
            on      tdo.broker_ticker_reference         = ed.broker_ticker_reference

            cross
            apply   ( select  price         = (cc.offer + cc.bid) / 2.0 ) p

            cross
            apply   ( select  notional_size = ed.contract_size ) s

            cross
            apply   ( select  spread_notional_value_in_eur            = nullif(s.notional_size * ((cc.offer - cc.bid) / cc.base_exchange_rate)  , 0)
                      ,       price_volatility_notional_value_in_eur  = nullif(s.notional_size * (v.price_volatility  / cc.base_exchange_rate)    , 0)  
                      ,       min_required_exposure_size              = nullif(coalesce(tdo.min_deal_size, ed.min_deal_size)                      , 0)
                      /*      Parked  */
                      --,       offer_notional_value_in_eur             = nullif(s.notional_size * (cc.offer / cc.base_exchange_rate)               , 0)
                      --,       bid_notional_value_in_eur               = nullif(s.notional_size * (cc.bid   / cc.base_exchange_rate)               , 0)
                      --,       price_notional_value_in_eur             = nullif(s.notional_size * (p.price  / cc.base_exchange_rate)               , 0)
                      ) n


            where   cc.timestamp                        = @timestamp
            and     cc.base_exchange_rate               is not null
            --and     cc.broker_ticker_reference          = @broker_ticker_reference  
            ) x
  cross
  apply   ( select  exposure_size  = (@capital * (@risk_percentage / 100.0) / x.price_volatility_notional_value_in_eur)  ) es

  cross
  apply   ( select  exposure_spread_notional_value_in_eur           = es.exposure_size * spread_notional_value_in_eur
            ,       exposure_price_volatility_notional_value_in_eur = es.exposure_size * price_volatility_notional_value_in_eur ) ex
)

go

declare @timestamp              datetime2       = dbo.round_minute(getutcdate()) --'2021-12-23 16:00:00'
declare @time_in_market         int             = 8*60--5*24*60
declare @capital                decimal(38,19)  = 1118.00
declare @risk_percentage        decimal(38,19)  = 1.00 

--set     @timestamp              = dbo.round_minute(@timestamp)

select  broker_ticker_reference     = e.broker_ticker_reference                        
,       name                        = e.name                                           
,       rel_volat_to_spread_rat     = e.relative_volatility_to_spread_ratio                                          
,       test_score                  = e.client_sentiment_strength * e.relative_volatility_to_spread_ratio
,       expo_size                   = e.exposure_size                  
,       client_sent_strength        = e.client_sentiment_strength
,       _                           = '          >>>>'
,       is_valid                    = e.is_expo_size_valid                                       
,       min_size                    = e.min_required_exposure_size                     
,       expo_spread                 = e.exposure_spread_notional_value_in_eur          
,       expo_volat                  = e.exposure_price_volatility_notional_value_in_eur
,       rel_volat_perc              = e.relative_volatility_perc             
,       spread_to_volat_rat         = e.volatility_to_spread_ratio                     
,       client_long_perc            = e.client_long_perc                                            
,       client_short_perc           = e.client_short_perc   

from    dbo.get_exposure_insight_v2 ( @timestamp            
                                    , @time_in_market  
                                    , @capital              
                                    , @risk_percentage      ) e
where   e.is_expo_size_valid        = 1
and     e.client_sentiment_strength >= 60
order
--by      e.relative_volatility_to_spread_ratio desc
by  test_score desc

