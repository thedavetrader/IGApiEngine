﻿create procedure execute_sql_script
	@message nvarchar(max)
as begin

	set nocount on

	insert api_request_queue_item (
		request
	,	parameter
	,	execute_asap 
	--TODO: request_concurrency_max
	)
	select	'ExecuteSqlScript'
	,		@message
	,		1

end

go

--execute_sql_script 'exec speak ''The cat crabs the curls from the stairs.'''