﻿create procedure recreate_watchlist
    @name       nvarchar(4000)
,   @epic_list  epic_list readonly
as begin

  set nocount on

  declare @watchlist_id   nvarchar(4000)

  select  @watchlist_id = w.watchlist_id
  from    watchlist   w
  where   w.name      = @name
  
  if @watchlist_id is not null
    exec  delete_watchlist
          @watchlist_id = @watchlist_id

  exec  create_watchlist
        @name         = @name
  ,     @epic_list    = @epic_list

end