﻿create procedure api_engine_restart
	@immediately	bit = 0
as begin

	set nocount on

	insert	api_request_queue_item (
			request
	,		execute_asap 
	)
	select	'Restart'
	,		@immediately

end

go

--api_engine_restart	@immediately = 1