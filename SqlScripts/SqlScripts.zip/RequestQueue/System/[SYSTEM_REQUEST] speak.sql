﻿create procedure speak
	@message nvarchar(max)
as begin

	set nocount on

	insert api_request_queue_item (
		request
	,	parameter
	,	execute_asap 
	)
	select	'Speak'
	,		@message
	,		1

end

go

--speak 'The cat crabs the curls from the stairs.'