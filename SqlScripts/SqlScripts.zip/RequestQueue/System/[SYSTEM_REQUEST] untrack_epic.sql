﻿create procedure untrack_epic
	@epics epic_list readonly
as begin

	set nocount on

	insert api_request_queue_item (
		request
	,	parameter
	,	execute_asap )
	select	request			= 'RemoveStreamListEpic'
	,		parameter		= (	select	epic
								from	@epics
								for		json path )
	,		execute_asap	= 1

end

go

--declare	@epics epic_list

--insert	@epics (epic)
--select	epic		= td.broker_ticker_reference
--from	tdt_live..ticker_detail	td
--join	epic_detail	ed
--on		ed.epic		= td.broker_ticker_reference
--where	ed.streaming_prices_available = 1
--and		ed.epic		= 'CC.D.DX.UNC.IP'
--order
--by		broker_ticker_reference asc
----offset	5 rows fetch next 5 rows only

--exec	untrack_epic	@epics = @epics