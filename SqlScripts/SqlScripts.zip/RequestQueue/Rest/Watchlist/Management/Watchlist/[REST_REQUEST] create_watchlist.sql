
go

if type_id('epic_list') is null
    create type epic_list as table (
        epic   nvarchar(128)    primary key nonclustered )
    with (memory_optimized = on)

go


create procedure create_watchlist
    @name       nvarchar(4000)
,   @epic_list  epic_list readonly
as begin

    set nocount on

    declare @message                    nvarchar(max)
    declare @timeout                    int             = 60 * 100;
    declare @found                      bit = 0
    declare @api_engine_status_is_alive bit = 0
    declare @retry                      int = 0

    if exists (select 1 from watchlist where name = @name)
        throw 51000, 'The specified watchlist name already exists.', 1

    insert  api_request_queue_item (
            request
    ,       parameter
    ,       execute_asap    )
    select  request         = 'CreateWatchlist'
    ,       parameter       =   (   select  name    = @name
                                    ,       epics   = json_query( '['   
                                                                + ( select  string_agg (quotename(ed.epic, '"'), ',')
                                                                    from    @epic_list  el
                                                                    join    epic_detail ed
                                                                    on      ed.epic     = el.epic )
                                                                + ']')
                                    for json path, without_array_wrapper  )
    ,       execute_asap    = 1

    while   (   @found = 0  or @api_engine_status_is_alive = 0)
    and     @retry < @timeout
    begin

      set     @api_engine_status_is_alive = dbo.get_api_engine_status_is_alive()

      select  @found    = 1
      from    watchlist w
      where   w.name    = @name

      waitfor delay '00:00:00:010'

      set @retry += 1

    end

    if @found = 1 and @api_engine_status_is_alive = 1
    begin

      set @message = 'Watchlist "' + @name + '" is  created.'      
      raiserror(@message , 10, 10) with nowait

    end
    else
    begin
        
      if  @api_engine_status_is_alive = 0
      begin 

        --      Api interface is not alive or is in abnormal state. 
        --      Prevent the request will be untimely executed when interface is recovered by removing it from queue.
        delete  rrq
        from    api_request_queue_item  rrq
        where   request                 = 'CreateWatchlist'

        set @message = 'ApiEngine does not report active and alive.'
        raiserror(@message, 10, 10) with nowait

      end
        
      if  @found = 0
      begin
        
        set @message = 'Failed to create Watchlist "' + @name + '".'
        raiserror(@message, 10, 10) with nowait

      end

      return -2

    end

end

go

--declare @epic_list epic_list

--insert  @epic_list select epic from epic_detail

--exec    create_watchlist 
--        @name       = 'TEST'
--,       @epic_list  = @epic_list

/*

{"name":"TEST","epics":["CS.D.BITCOIN.CFD.IP","CS.D.ETHUSD.CFE.IP","IX.D.RUSSELL.IFM.IP","IX.D.SPTRD.IFE.IP","UC.D.PYPLVUS.CASH.IP"]}
{"name":"TESTTT","epics":["CS.D.BITCOIN.CFD.IP","CS.D.ETHUSD.CFE.IP"]}
*/